import dotenv from 'dotenv';
import { appendOrderToSheet } from './sheetsService.js';

dotenv.config();

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_KEY;

const DEFAULT_SHOP_ID = 'shop-default-123';

// State machine constants
const STATES = {
  IDLE: null,
  GETTING_NAME: 'GETTING_NAME',
  GETTING_ADDRESS: 'GETTING_ADDRESS',
  GETTING_PHONE: 'GETTING_PHONE',
  AWAITING_RECEIPT: 'AWAITING_RECEIPT'
};

const HEADERS = {
  'apikey': SUPABASE_KEY,
  'Authorization': `Bearer ${SUPABASE_KEY}`,
  'Content-Type': 'application/json',
  'Prefer': 'return=representation'
};

async function supabaseFetch(table, method = 'GET', body = null, query = '') {
  const url = `${SUPABASE_URL}/rest/v1/${table}${query}`;
  const options = { method, headers: { ...HEADERS } };
  if (body) options.body = JSON.stringify(body);
  const res = await fetch(url, options);
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || data.msg || 'Supabase request failed');
  return data;
}

async function getLatestState(userId, shopId) {
  try {
    const chats = await supabaseFetch('chats', 'GET', null,
      `?select=state,pending_order_id,reservation_expires_at&user_id=eq.${userId}&shop_id=eq.${shopId}&order=created_at.desc&limit=1`);
    if (chats && chats.length > 0) {
      const chat = chats[0];
      // Check if reservation expired
      if (chat.reservation_expires_at) {
        const expiresAt = new Date(chat.reservation_expires_at);
        if (expiresAt <= new Date()) {
          // Expired - return to IDLE
          if (chat.pending_order_id) {
            try {
              await supabaseFetch('orders', 'PATCH', { status: 'rejected' },
                `?id=eq.${chat.pending_order_id}`);
            } catch (e) { /* ignore */ }
          }
          return { state: STATES.IDLE, pendingOrderId: null };
        }
      }
      return { state: chat.state, pendingOrderId: chat.pending_order_id };
    }
    return { state: STATES.IDLE, pendingOrderId: null };
  } catch (err) {
    console.error('Error getting state:', err.message);
    return { state: STATES.IDLE, pendingOrderId: null };
  }
}

async function getShopInfo(shopId) {
  try {
    const shops = await supabaseFetch('shops', 'GET', null, `?select=*&id=eq.${shopId}`);
    return shops && shops.length > 0 ? shops[0] : { id: shopId, name: 'فروشگاه', card_number: '' };
  } catch (err) {
    return { id: shopId, name: 'فروشگاه', card_number: '' };
  }
}

async function saveChat(userId, platform, message, response, intent, shopId, state, reservationExpiresAt, pendingOrderId) {
  try {
    await supabaseFetch('chats', 'POST', {
      user_id: userId,
      platform,
      message,
      response,
      intent,
      shop_id: shopId,
      state,
      reservation_expires_at: reservationExpiresAt,
      pending_order_id: pendingOrderId
    });
  } catch (err) {
    console.error('Error saving chat:', err.message);
  }
}

function detectIntent(message) {
  const lower = message.toLowerCase();
  const orderWords = ['سفارش', 'خرید', 'می‌خوام', 'میخوام', 'بخر', 'بده', 'order', 'buy', 'purchase', 'want'];
  if (orderWords.some(w => lower.includes(w))) return 'order';
  if (lower.includes('قیمت') || lower.includes('price') || lower.includes('cost')) return 'price';
  if (lower.includes('محصول') || lower.includes('product') || lower.includes('کالا') || lower.includes('لیست')) return 'product';
  if (lower.includes('کمک') || lower.includes('help') || lower.includes('support')) return 'support';
  return 'general';
}

function extractQuantity(message) {
  const lower = message.toLowerCase();
  const persianNumbers = {
    'یک': 1, 'یکه': 1, 'دو': 2, 'سه': 3, 'چهار': 4, 'پنج': 5,
    'شش': 6, 'هفت': 7, 'هشت': 8, 'نه': 9, 'ده': 10
  };

  for (const [word, num] of Object.entries(persianNumbers)) {
    if (num > 0) {
      const patterns = [`${word} عدد`, `${word}تا`, `${word} تا`, `${word}دونه`, `${word} دونه`];
      if (patterns.some(p => lower.includes(p))) return num;
    }
  }

  for (const [word, num] of Object.entries(persianNumbers)) {
    if (num > 0 && lower.includes(word)) return num;
  }

  const digitMatch = lower.match(/(\d+)\s*(?:عدد|تا|دونه)/);
  if (digitMatch) return parseInt(digitMatch[1], 10);

  const standaloneDigit = lower.match(/\b(\d+)\b/);
  if (standaloneDigit) return parseInt(standaloneDigit[1], 10);

  return 1;
}

function formatPrice(price) {
  return Number(price).toLocaleString('fa-IR');
}

function formatProduct(p) {
  const stockLabel = p.stock > 0 ? `موجود (${p.stock} عدد)` : 'ناموجود';
  return `${p.name}\n   قیمت: ${formatPrice(p.price)} تومان\n   وضعیت: ${stockLabel}\n   ${p.description}`;
}

function validatePhone(phone) {
  const cleaned = phone.replace(/\D/g, '');
  return /^09\d{9}$/.test(cleaned);
}

function cleanPhone(phone) {
  return phone.replace(/\D/g, '');
}

async function searchProducts(message, shopId) {
  try {
    const products = await supabaseFetch('products', 'GET', null,
      `?select=*&shop_id=eq.${shopId}&order=created_at.asc`);
    if (!products || products.length === 0) {
      return { found: false, products: [] };
    }

    const lowerMessage = message.toLowerCase();
    const matched = products.filter(p => {
      const lowerName = p.name.toLowerCase();
      return lowerMessage.includes(lowerName) ||
             lowerName.includes(lowerMessage) ||
             lowerMessage.split(' ').some(word => word.length > 2 && lowerName.includes(word));
    });

    if (matched.length > 0) {
      return { found: true, matched: true, products: matched };
    }
    return { found: true, matched: false, products };
  } catch (err) {
    console.error('Error searching products:', err.message);
    return { found: false, products: [] };
  }
}

// STATE: IDLE - Handle general questions and initiate order flow
async function handleIDLE(userId, platform, message, shopId) {
  const intent = detectIntent(message);

  if (intent === 'price' || intent === 'product') {
    const result = await searchProducts(message, shopId);
    if (!result.found || result.products.length === 0) {
      return { response: 'متأسفانه در حال حاضر محصولی در فروشگاه موجود نیست.', newState: STATES.IDLE };
    }
    if (result.matched) {
      const list = result.products.map(formatProduct).join('\n\n');
      return { response: `محصول یافت شد:\n\n${list}\n\nآیا می‌خواهید سفارش دهید؟`, newState: STATES.IDLE };
    }
    const list = result.products.map(formatProduct).join('\n\n');
    return { response: `لیست محصولات موجود:\n\n${list}\n\nکدام محصول مدنظر شماست؟`, newState: STATES.IDLE };
  }

  if (intent === 'order') {
    const orderResult = await initiateOrder(userId, message, shopId);
    return orderResult;
  }

  const responses = {
    support: 'من در خدمت هستم! لطفاً بگویید چه مشکلی دارید تا کمکتان کنم.',
    general: 'ممنون از پیام شما! من دستیار هوشمند فروشگاه هستم. چگونه می‌توانم کمکتان کنم؟'
  };
  return { response: responses[intent] || responses.general, newState: STATES.IDLE };
}

// Create draft order and transition to GETTING_NAME
async function initiateOrder(userId, message, shopId) {
  const result = await searchProducts(message, shopId);

  if (!result.found || result.products.length === 0) {
    return { response: 'متأسفانه در حال حاضر محصولی در فروشگاه موجود نیست.', newState: STATES.IDLE };
  }

  if (!result.matched) {
    const list = result.products.map(formatProduct).join('\n\n');
    return { response: `لطفاً مشخص کنید کدام محصول را می‌خواهید سفارش دهید:\n\n${list}`, newState: STATES.IDLE };
  }

  const product = result.products[0];
  const quantity = extractQuantity(message);

  if (product.stock <= 0) {
    return { response: `متأسفانه ${product.name} در حال حاضر ناموجود است. لطفاً بعداً تلاش کنید.`, newState: STATES.IDLE };
  }

  if (quantity > product.stock) {
    return { response: `متأسفانه فقط ${product.stock} عدد از ${product.name} در انبار موجود است. آیا می‌خواهید ${product.stock} عدد سفارش دهید؟`, newState: STATES.IDLE };
  }

  const totalPrice = Number(product.price) * quantity;

  // Create DRAFT order (pending_receipt, but no customer data yet)
  try {
    const orderData = await supabaseFetch('orders', 'POST', {
      user_id: userId,
      product_id: product.id,
      quantity,
      total_price: totalPrice,
      status: 'pending_receipt',
      shop_id: shopId
    });

    const orderId = orderData?.[0]?.id;

    // Decrease stock
    const newStock = product.stock - quantity;
    await fetch(`${SUPABASE_URL}/rest/v1/products?id=eq.${product.id}`, {
      method: 'PATCH',
      headers: { ...HEADERS },
      body: JSON.stringify({ stock: newStock })
    });

    return {
      response: `عالیه! برای ثبت سفارشتون لطفاً نام و نام خانوادگی خودتون رو بفرستید.`,
      newState: STATES.GETTING_NAME,
      pendingOrderId: orderId,
      reservationExpiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString()
    };
  } catch (err) {
    console.error('Error creating draft order:', err.message);
    return { response: 'متأسفانه در ثبت سفارش مشکلی پیش آمد. لطفاً دوباره تلاش کنید.', newState: STATES.IDLE };
  }
}

// STATE: GETTING_NAME
async function handleGETTING_NAME(userId, platform, message, shopId, pendingOrderId) {
  const name = message.trim();
  if (name.length < 2) {
    return { response: 'لطفاً یک نام معتبر وارد کنید.', newState: STATES.GETTING_NAME, pendingOrderId };
  }

  try {
    await supabaseFetch('orders', 'PATCH', { customer_name: name }, `?id=eq.${pendingOrderId}`);
    return { response: 'لطفاً آدرس دقیق و کد پستی خودتون رو برای ارسال وارد کنید.', newState: STATES.GETTING_ADDRESS, pendingOrderId };
  } catch (err) {
    console.error('Error updating name:', err.message);
    return { response: 'مشکلی پیش آمد. لطفاً دوباره نام خود را وارد کنید.', newState: STATES.GETTING_NAME, pendingOrderId };
  }
}

// STATE: GETTING_ADDRESS
async function handleGETTING_ADDRESS(userId, platform, message, shopId, pendingOrderId) {
  const address = message.trim();
  if (address.length < 5) {
    return { response: 'لطفاً یک آدرس معتبر با کد پستی وارد کنید.', newState: STATES.GETTING_ADDRESS, pendingOrderId };
  }

  try {
    await supabaseFetch('orders', 'PATCH', { shipping_address: address }, `?id=eq.${pendingOrderId}`);
    return { response: 'لطفاً یک شماره تماس معتبر (شروع با 09) وارد کنید.', newState: STATES.GETTING_PHONE, pendingOrderId };
  } catch (err) {
    console.error('Error updating address:', err.message);
    return { response: 'مشکلی پیش آمد. لطفاً دوباره آدرس را وارد کنید.', newState: STATES.GETTING_ADDRESS, pendingOrderId };
  }
}

// STATE: GETTING_PHONE
async function handleGETTING_PHONE(userId, platform, message, shopId, pendingOrderId, reservationExpiresAt) {
  const phone = cleanPhone(message);

  if (!validatePhone(phone)) {
    return { response: 'شماره وارد شده معتبر نیست. لطفاً یک شماره موبایل 11 رقمی که با 09 شروع شود وارد کنید.', newState: STATES.GETTING_PHONE, pendingOrderId };
  }

  try {
    await supabaseFetch('orders', 'PATCH', { phone }, `?id=eq.${pendingOrderId}`);

    // Get order details for invoice
    const orders = await supabaseFetch('orders', 'GET', null, `?select=*,products(name,price)&id=eq.${pendingOrderId}`);
    const order = orders?.[0];
    const shop = await getShopInfo(shopId);

    if (!order) {
      return { response: 'سفارش یافت نشد. لطفاً دوباره تلاش کنید.', newState: STATES.IDLE };
    }

    // Generate invoice
    const invoice = `فاکتور سفارش
━━━━━━━━━━━━━━━━
محصول: ${order.products?.name || 'نامشخص'}
تعداد: ${order.quantity}
قیمت واحد: ${formatPrice(order.products?.price || 0)} تومان
━━━━━━━━━━━━━━━━
قیمت کل: ${formatPrice(order.total_price)} تومان
━━━━━━━━━━━━━━━━

مشخصات گیرنده:
نام: ${order.customer_name}
آدرس: ${order.shipping_address}
تلفن: ${order.phone}

برای پرداخت، مبلغ ${formatPrice(order.total_price)} تومان را به شماره کارت زیر واریز کنید:
💳 ${shop.card_number || 'شماره کارت ثبت نشده'}

پس از پرداخت، عکس رسید بانکی را ارسال کنید.
سفارش تا ۱ ساعت رزرو می‌شود.`;

    // Try Google Sheets (non-blocking)
    appendOrderToSheet(null, {
      orderId: pendingOrderId,
      userId,
      productName: order.products?.name || '',
      quantity: order.quantity,
      totalPrice: order.total_price,
      status: 'pending_receipt',
      timestamp: new Date().toISOString()
    }).catch(() => {});

    return {
      response: invoice,
      newState: STATES.AWAITING_RECEIPT,
      pendingOrderId,
      reservationExpiresAt
    };
  } catch (err) {
    console.error('Error in phone validation:', err.message);
    return { response: 'مشکلی پیش آمد. لطفاً دوباره شماره تماس را وارد کنید.', newState: STATES.GETTING_PHONE, pendingOrderId };
  }
}

// STATE: AWAITING_RECEIPT - Handle receipt upload
async function handleAWAITING_RECEIPT(userId, platform, message, shopId, pendingOrderId, imagePayload, reservationExpiresAt) {
  if (!imagePayload) {
    return {
      response: 'در انتظار رسید پرداخت هستیم. لطفاً تصویر رسید بانکی خود را ارسال کنید.',
      newState: STATES.AWAITING_RECEIPT,
      pendingOrderId,
      reservationExpiresAt
    };
  }

  const receiptUrl = imagePayload.url || imagePayload.link || '';
  const trackingCode = imagePayload.tracking_code || imagePayload.trackingCode || null;

  // Anti-fraud: check if tracking code already used
  if (trackingCode) {
    try {
      const duplicateCheck = await supabaseFetch('orders', 'GET', null,
        `?select=id&tracking_code=eq.${trackingCode}&status=eq.approved&limit=1`);
      if (duplicateCheck && duplicateCheck.length > 0) {
        await supabaseFetch('orders', 'PATCH', { status: 'rejected' }, `?id=eq.${pendingOrderId}`);
        return {
          response: `کد پیگیری ${trackingCode} قبلاً در یک سفارش تأیید‌شده استفاده شده است.\nارسال رسید تکراری مجاز نیست. سفارش شما رد شد.`,
          newState: STATES.IDLE,
          pendingOrderId: null,
          isFraud: true
        };
      }
    } catch (err) {
      console.error('Error checking duplicate tracking code:', err.message);
    }
  }

  try {
    const updateBody = { status: 'awaiting_approval' };
    if (receiptUrl) updateBody.receipt_url = receiptUrl;
    if (trackingCode) updateBody.tracking_code = trackingCode;

    await supabaseFetch('orders', 'PATCH', updateBody, `?id=eq.${pendingOrderId}`);

    const responseText = `رسید پرداخت شما دریافت شد و در حال بررسی است.\n` +
      (trackingCode ? `کد پیگیری: ${trackingCode}\n` : '') +
      `نتیجه تأیید به زودی اعلام خواهد شد. با تشکر از صبر شما!`;

    return {
      response: responseText,
      newState: STATES.IDLE,
      pendingOrderId: null
    };
  } catch (err) {
    console.error('Error processing receipt:', err.message);
    return {
      response: 'مشکلی در ثبت رسید پیش آمد. لطفاً دوباره تلاش کنید.',
      newState: STATES.AWAITING_RECEIPT,
      pendingOrderId,
      reservationExpiresAt
    };
  }
}

// Main processMessage function with state machine
export async function processMessage(userId, platform, message, shopId, imagePayload) {
  if (!message || !message.trim()) {
    throw new Error('Message cannot be empty');
  }

  const sid = shopId || DEFAULT_SHOP_ID;

  // Get current state
  const { state, pendingOrderId, reservationExpiresAt } = await getLatestState(userId, sid);

  let result;
  const intent = detectIntent(message);

  // STATE ROUTER
  switch (state) {
    case STATES.GETTING_NAME:
      result = await handleGETTING_NAME(userId, platform, message, sid, pendingOrderId);
      break;

    case STATES.GETTING_ADDRESS:
      result = await handleGETTING_ADDRESS(userId, platform, message, sid, pendingOrderId);
      break;

    case STATES.GETTING_PHONE:
      result = await handleGETTING_PHONE(userId, platform, message, sid, pendingOrderId, reservationExpiresAt);
      break;

    case STATES.AWAITING_RECEIPT:
      result = await handleAWAITING_RECEIPT(userId, platform, message, sid, pendingOrderId, imagePayload, reservationExpiresAt);
      break;

    case STATES.IDLE:
    default:
      // If image sent but not in AWAITING_RECEIPT state, ignore image
      if (imagePayload) {
        result = { response: 'لطفاً ابتدا سفارش خود را ثبت کنید.', newState: STATES.IDLE };
      } else {
        result = await handleIDLE(userId, platform, message, sid);
      }
      break;
  }

  // Save chat with state
  const expiresAt = result.reservationExpiresAt ||
    (result.pendingOrderId ? new Date(Date.now() + 60 * 60 * 1000).toISOString() : null);

  await saveChat(
    userId,
    platform,
    message,
    result.response,
    result.isFraud ? 'receipt_fraud' : intent,
    sid,
    result.newState,
    expiresAt,
    result.pendingOrderId
  );

  return {
    success: true,
    response: result.response,
    intent: result.isFraud ? 'receipt_fraud' : intent,
    conversationId: null
  };
}

export async function getChatHistory(userId, shopId) {
  try {
    const sid = shopId || DEFAULT_SHOP_ID;
    const data = await supabaseFetch('chats', 'GET', null,
      `?select=*&user_id=eq.${userId}&shop_id=eq.${sid}&order=created_at.asc&limit=50`);
    return data || [];
  } catch (err) {
    console.error('Error fetching chat history:', err.message);
    return [];
  }
}
