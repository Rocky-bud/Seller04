import { Router } from 'express';
import dotenv from 'dotenv';

dotenv.config();

const router = Router();

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.VITE_SUPABASE_ANON_KEY || process.env.SUPABASE_KEY;

const HEADERS = {
  'apikey': SUPABASE_KEY,
  'Authorization': `Bearer ${SUPABASE_KEY}`,
  'Content-Type': 'application/json'
};

router.get('/user/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const shopId = req.query.shopId;

    if (!userId) {
      return res.status(400).json({ success: false, error: 'Missing userId parameter' });
    }

    let url = `${SUPABASE_URL}/rest/v1/orders?select=*,products(name,price)&user_id=eq.${userId}`;
    if (shopId) {
      url += `&shop_id=eq.${shopId}`;
    }
    url += '&order=created_at.desc';

    const response = await fetch(url, { headers: HEADERS });
    const orders = await response.json();

    if (!response.ok) {
      return res.status(500).json({ success: false, error: orders.message || 'Failed to fetch orders' });
    }

    return res.json({
      success: true,
      userId,
      count: orders.length,
      data: orders
    });
  } catch (err) {
    console.error('Error in orders/user/:userId:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
