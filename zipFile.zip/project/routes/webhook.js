import { Router } from 'express';
import { processMessage } from '../services/aiService.js';

const router = Router();

router.post('/telegram', async (req, res) => {
  try {
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ success: false, error: 'No message object in request body' });
    }

    const chatId = message.chat?.id;
    const text = message.text;

    if (!chatId || !text) {
      return res.status(400).json({ success: false, error: 'Missing chat.id or text in message' });
    }

    const userId = String(chatId);
    const platform = 'telegram';

    const result = await processMessage(userId, platform, text);

    return res.json({
      success: true,
      chatId,
      reply: result.response,
      intent: result.intent,
      conversationId: result.conversationId
    });
  } catch (err) {
    console.error('Error in webhook/telegram:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
