import express from 'express';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import { processMessage, getChatHistory } from './services/aiService.js';
import webhookRouter from './routes/webhook.js';
import ordersRouter from './routes/orders.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Global rate limiter: 100 requests per 15 minutes per IP
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً بعداً تلاش کنید.'
  }
});

// Strict rate limiter for chat/webhook: 20 requests per minute per IP
const strictLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'درخواست‌های بیش از حد مجاز. لطفاً قبل از ارسال مجدد کمی صبر کنید.'
  }
});

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials in environment variables');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

// Middleware
app.use(express.json());

// Apply global rate limiter to all API routes
app.use('/api/', globalLimiter);

// Health check route with database connection test
app.get('/api/status', async (req, res) => {
  try {
    // Test database connection by querying the products table
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .limit(1);

    if (error) {
      return res.json({
        status: 'ok',
        database: {
          connected: false,
          error: error.message
        },
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      status: 'ok',
      database: {
        connected: true,
        table: 'products',
        rowsReturned: data?.length || 0
      },
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    res.json({
      status: 'ok',
      database: {
        connected: false,
        error: err.message
      },
      timestamp: new Date().toISOString()
    });
  }
});

// AI Chat endpoint (strict rate limit)
app.post('/api/chat', strictLimiter, async (req, res) => {
  try {
    const { userId, platform, message, shopId, imagePayload } = req.body;

    if (!userId || !platform || !message) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: userId, platform, message'
      });
    }

    const result = await processMessage(userId, platform, message, shopId, imagePayload);

    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    console.error('Error in /api/chat:', err);
    res.status(500).json({
      success: false,
      error: err.message || 'Failed to process message'
    });
  }
});

// Chat history endpoint
app.get('/api/chat/history/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const shopId = req.query.shopId;

    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'Missing userId parameter'
      });
    }

    const history = await getChatHistory(userId, shopId);

    res.json({
      success: true,
      data: history
    });
  } catch (err) {
    console.error('Error in /api/chat/history:', err);
    res.status(500).json({
      success: false,
      error: err.message || 'Failed to fetch chat history'
    });
  }
});

// Mount route files (strict rate limit on webhook)
app.use('/api/webhook', strictLimiter, webhookRouter);
app.use('/api/orders', ordersRouter);

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`API status endpoint: http://localhost:${PORT}/api/status`);
});
