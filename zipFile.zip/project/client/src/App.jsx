import { ShopProvider, useShop } from './contexts/ShopContext';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Receipts from './pages/Receipts';
import Products from './pages/Products';
import Settings from './pages/Settings';
import { useState } from 'react';

function AppContent() {
  const { isAuthenticated } = useShop();
  const [activePage, setActivePage] = useState('dashboard');

  if (!isAuthenticated) return <Login />;

  const pages = {
    dashboard: Dashboard,
    receipts: Receipts,
    products: Products,
    settings: Settings,
  };

  const Page = pages[activePage] || Dashboard;

  return (
    <div className="flex min-h-screen bg-slate-50" dir="rtl">
      <Sidebar activePage={activePage} onNavigate={setActivePage} />
      <main className="flex-1 overflow-auto">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <Page />
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ShopProvider>
      <AppContent />
    </ShopProvider>
  );
}
