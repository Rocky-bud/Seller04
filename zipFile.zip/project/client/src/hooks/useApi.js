const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

const HEADERS = {
  'apikey': SUPABASE_KEY,
  'Authorization': `Bearer ${SUPABASE_KEY}`,
  'Content-Type': 'application/json',
  'Prefer': 'return=representation'
};

export async function fetchOrders(shopId, status) {
  let query = `?select=*,products(name,price,stock)&shop_id=eq.${shopId}`;
  if (status) query += `&status=eq.${status}`;
  query += '&order=created_at.desc';

  const res = await fetch(`${SUPABASE_URL}/rest/v1/orders${query}`, { headers: HEADERS });
  if (!res.ok) throw new Error('Failed to fetch orders');
  return res.json();
}

export async function updateOrderStatus(orderId, status) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/orders?id=eq.${orderId}`, {
    method: 'PATCH',
    headers: HEADERS,
    body: JSON.stringify({ status })
  });
  if (!res.ok) throw new Error('Failed to update order');
  return res.json();
}

export async function fetchProducts(shopId) {
  const query = `?select=*&shop_id=eq.${shopId}&order=created_at.asc`;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/products${query}`, { headers: HEADERS });
  if (!res.ok) throw new Error('Failed to fetch products');
  return res.json();
}

export async function fetchDashboardStats(shopId) {
  const [allOrders, pendingOrders, products] = await Promise.all([
    fetchOrders(shopId),
    fetchOrders(shopId, 'awaiting_approval'),
    fetchProducts(shopId)
  ]);

  const approvedOrders = allOrders.filter(o => o.status === 'approved');
  const totalRevenue = approvedOrders.reduce((sum, o) => sum + Number(o.total_price || 0), 0);
  const lowStockProducts = products.filter(p => p.stock <= 3 && p.stock > 0);

  return {
    totalRevenue,
    pendingCount: pendingOrders.length,
    lowStockAlerts: lowStockProducts,
    totalOrders: allOrders.length,
    approvedOrders: approvedOrders.length
  };
}
