import { createContext, useContext, useState, useCallback } from 'react';

const ShopContext = createContext(null);

export function ShopProvider({ children }) {
  const [shopId, setShopId] = useState(() => localStorage.getItem('shopId') || '');
  const [isAuthenticated, setIsAuthenticated] = useState(() => !!localStorage.getItem('shopId'));

  const login = useCallback((code) => {
    const trimmed = code.trim();
    if (!trimmed) return false;
    localStorage.setItem('shopId', trimmed);
    setShopId(trimmed);
    setIsAuthenticated(true);
    return true;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('shopId');
    setShopId('');
    setIsAuthenticated(false);
  }, []);

  return (
    <ShopContext.Provider value={{ shopId, isAuthenticated, login, logout }}>
      {children}
    </ShopContext.Provider>
  );
}

export function useShop() {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error('useShop must be used within ShopProvider');
  return ctx;
}
