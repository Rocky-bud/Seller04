import { useShop } from '../contexts/ShopContext';
import { Settings as SettingsIcon, MessageSquare, Globe, Smartphone, Copy } from 'lucide-react';
import { useState } from 'react';

const channels = [
  { id: 'web', label: 'وب‌سایت', icon: Globe, status: 'فعال', color: 'text-success-600 bg-success-50' },
  { id: 'telegram', label: 'تلگرام', icon: Smartphone, status: 'غیرفعال', color: 'text-slate-500 bg-slate-100' },
  { id: 'whatsapp', label: 'واتساپ', icon: MessageSquare, status: 'غیرفعال', color: 'text-slate-500 bg-slate-100' },
];

export default function Settings() {
  const { shopId } = useShop();
  const [copied, setCopied] = useState(false);

  const copyShopId = () => {
    navigator.clipboard.writeText(shopId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">تنظیمات ربات</h1>
        <p className="text-sm text-slate-500 mt-1">مدیریت کانال‌ها و تنظیمات هوش مصنوعی</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center">
            <SettingsIcon className="w-5 h-5 text-primary-600" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-700">کد اختصاصی فروشگاه</h3>
            <p className="text-xs text-slate-400">برای اتصال ربات به فروشگاه از این کد استفاده کنید</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <code className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-700 font-mono" dir="ltr">
            {shopId}
          </code>
          <button
            onClick={copyShopId}
            className={`px-4 py-3 rounded-xl text-sm font-medium transition-all ${
              copied
                ? 'bg-success-50 text-success-600'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Copy className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-700 mb-4">کانال‌های ورودی</h3>
        <div className="space-y-3">
          {channels.map(({ id, label, icon: Icon, status, color }) => (
            <div key={id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium text-slate-700">{label}</span>
              </div>
              <span className={`text-xs font-medium px-3 py-1 rounded-lg ${color}`}>
                {status}
              </span>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-400 mt-4">کانال‌های بیشتر به زودی اضافه خواهند شد</p>
      </div>
    </div>
  );
}
