import { useState, useEffect, useCallback } from 'react';
import { useShop } from '../contexts/ShopContext';
import { fetchOrders, updateOrderStatus } from '../hooks/useApi';
import { formatToman, formatDate, statusLabels, statusColors } from '../utils/helpers';
import { FileCheck, CheckCircle2, XCircle, Eye, X, RefreshCw, ImageIcon, Hash } from 'lucide-react';

export default function Receipts() {
  const { shopId } = useShop();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [actionLoading, setActionLoading] = useState(null);

  const loadOrders = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchOrders(shopId, 'awaiting_approval');
      setOrders(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [shopId]);

  useEffect(() => { loadOrders(); }, [loadOrders]);

  const handleAction = async (orderId, newStatus) => {
    setActionLoading(orderId + newStatus);
    try {
      await updateOrderStatus(orderId, newStatus);
      setOrders(prev => prev.filter(o => o.id !== orderId));
      if (selected?.id === orderId) setSelected(null);
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoading(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-800">تأیید فیش‌های مالی</h1>
          <p className="text-sm text-slate-500 mt-1">
            سفارشاتی که رسید پرداخت آن‌ها ارسال شده و منتظر تأیید شما هستند
          </p>
        </div>
        <button
          onClick={loadOrders}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-600 hover:bg-slate-50 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          بروزرسانی
        </button>
      </div>

      {orders.length === 0 && !loading ? (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-12 text-center">
          <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <FileCheck className="w-8 h-8 text-slate-300" />
          </div>
          <h3 className="text-slate-600 font-medium mb-1">فیش مالی جدیدی وجود ندارد</h3>
          <p className="text-sm text-slate-400">سفارشات پس از ارسال رسید بانکی در اینجا نمایش داده می‌شوند</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50">
                  <th className="text-right text-xs font-semibold text-slate-500 px-5 py-3">شناسه مشتری</th>
                  <th className="text-right text-xs font-semibold text-slate-500 px-5 py-3">محصول</th>
                  <th className="text-right text-xs font-semibold text-slate-500 px-5 py-3">تعداد</th>
                  <th className="text-right text-xs font-semibold text-slate-500 px-5 py-3">مبلغ کل</th>
                  <th className="text-right text-xs font-semibold text-slate-500 px-5 py-3">کد پیگیری</th>
                  <th className="text-right text-xs font-semibold text-slate-500 px-5 py-3">تاریخ</th>
                  <th className="text-center text-xs font-semibold text-slate-500 px-5 py-3">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <tr
                    key={order.id}
                    className={`border-b border-slate-50 hover:bg-slate-50/50 transition-colors ${
                      selected?.id === order.id ? 'bg-primary-50/40' : ''
                    }`}
                  >
                    <td className="px-5 py-4 text-sm text-slate-700 font-mono" dir="ltr">{order.user_id}</td>
                    <td className="px-5 py-4 text-sm text-slate-700 font-medium">{order.products?.name || '---'}</td>
                    <td className="px-5 py-4 text-sm text-slate-600">{order.quantity} عدد</td>
                    <td className="px-5 py-4 text-sm font-semibold text-slate-800">{formatToman(order.total_price)}</td>
                    <td className="px-5 py-4 text-sm text-slate-600" dir="ltr">{order.tracking_code || '---'}</td>
                    <td className="px-5 py-4 text-sm text-slate-500">{formatDate(order.created_at)}</td>
                    <td className="px-5 py-4 text-center">
                      <button
                        onClick={() => setSelected(order)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-primary-50 text-primary-700 rounded-lg text-xs font-medium hover:bg-primary-100 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        بررسی رسید
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center py-8">
          <div className="w-6 h-6 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
        </div>
      )}

      {selected && (
        <ReceiptModal
          order={selected}
          onClose={() => setSelected(null)}
          onApprove={() => handleAction(selected.id, 'approved')}
          onReject={() => handleAction(selected.id, 'rejected')}
          actionLoading={actionLoading}
        />
      )}
    </div>
  );
}

function ReceiptModal({ order, onClose, onApprove, onReject, actionLoading }) {
  const isLoading = actionLoading === order.id + 'approved' || actionLoading === order.id + 'rejected';

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden animate-in"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-lg font-bold text-slate-800">بررسی رسید پرداخت</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-slate-100">
          <div className="flex-1 p-6 flex items-center justify-center min-h-[280px] bg-slate-50">
            {order.receipt_url ? (
              <img
                src={order.receipt_url}
                alt="رسید بانکی"
                className="max-w-full max-h-[400px] rounded-xl object-contain shadow-sm"
                onError={e => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }}
              />
            ) : null}
            <div
              className={`flex-col items-center justify-center text-slate-400 gap-3 ${order.receipt_url ? 'hidden' : 'flex'}`}
            >
              <ImageIcon className="w-12 h-12" />
              <span className="text-sm">تصویر رسید موجود نیست</span>
            </div>
          </div>

          <div className="flex-1 p-6 space-y-5">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">شناسه مشتری</span>
                <span className="text-sm font-mono text-slate-700" dir="ltr">{order.user_id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">محصول</span>
                <span className="text-sm font-medium text-slate-800">{order.products?.name || '---'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">تعداد</span>
                <span className="text-sm text-slate-700">{order.quantity} عدد</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">مبلغ کل</span>
                <span className="text-base font-bold text-slate-800">{formatToman(order.total_price)}</span>
              </div>
              {order.tracking_code && (
                <div className="flex justify-between items-center">
                  <span className="text-xs text-slate-500">کد پیگیری</span>
                  <span className="text-sm font-mono text-slate-700 flex items-center gap-1" dir="ltr">
                    <Hash className="w-3.5 h-3.5" />
                    {order.tracking_code}
                  </span>
                </div>
              )}
              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">تاریخ سفارش</span>
                <span className="text-sm text-slate-600">{formatDate(order.created_at)}</span>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4 space-y-3">
              <button
                onClick={onApprove}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-3 bg-success-600 hover:bg-success-500 text-white rounded-xl font-medium text-sm transition-all disabled:opacity-50 active:scale-[0.98]"
              >
                {actionLoading === order.id + 'approved' ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    تایید و ثبت نهایی
                  </>
                )}
              </button>
              <button
                onClick={onReject}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-3 bg-white border-2 border-danger-500 text-danger-600 hover:bg-danger-50 rounded-xl font-medium text-sm transition-all disabled:opacity-50 active:scale-[0.98]"
              >
                {actionLoading === order.id + 'rejected' ? (
                  <div className="w-5 h-5 border-2 border-danger-200 border-t-danger-600 rounded-full animate-spin" />
                ) : (
                  <>
                    <XCircle className="w-5 h-5" />
                    رد فیش / مغایرت مالی
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
