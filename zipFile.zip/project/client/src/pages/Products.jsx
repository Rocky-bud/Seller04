import { useState, useEffect, useCallback } from 'react';
import { useShop } from '../contexts/ShopContext';
import { fetchProducts } from '../hooks/useApi';
import { formatToman } from '../utils/helpers';
import { Package, RefreshCw, AlertTriangle, Box } from 'lucide-react';

export default function Products() {
  const { shopId } = useShop();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchProducts(shopId);
      setProducts(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [shopId]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-800">مدیریت محصولات</h1>
          <p className="text-sm text-slate-500 mt-1">لیست محصولات و موجودی انبار</p>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-600 hover:bg-slate-50 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          بروزرسانی
        </button>
      </div>

      {products.length === 0 && !loading ? (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-12 text-center">
          <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Package className="w-8 h-8 text-slate-300" />
          </div>
          <h3 className="text-slate-600 font-medium mb-1">محصولی ثبت نشده است</h3>
          <p className="text-sm text-slate-400">محصولات فروشگاه شما در اینجا نمایش داده می‌شوند</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map(p => (
            <div
              key={p.id}
              className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow overflow-hidden"
            >
              <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      p.stock > 3 ? 'bg-success-50' : p.stock > 0 ? 'bg-warning-50' : 'bg-danger-50'
                    }`}>
                      <Box className={`w-5 h-5 ${
                        p.stock > 3 ? 'text-success-600' : p.stock > 0 ? 'text-warning-600' : 'text-danger-600'
                      }`} />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-slate-800">{p.name}</h3>
                      <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">{p.description || 'بدون توضیحات'}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-50">
                  <span className="text-sm font-bold text-slate-800">{formatToman(p.price)}</span>
                  <div className="flex items-center gap-1.5">
                    {p.stock <= 3 && p.stock > 0 && <AlertTriangle className="w-3.5 h-3.5 text-warning-500" />}
                    <span className={`text-xs font-medium px-2 py-1 rounded-lg ${
                      p.stock > 3
                        ? 'bg-success-50 text-success-600'
                        : p.stock > 0
                          ? 'bg-warning-50 text-warning-600'
                          : 'bg-danger-50 text-danger-600'
                    }`}>
                      {p.stock > 0 ? `${p.stock} عدد` : 'ناموجود'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center py-8">
          <div className="w-6 h-6 border-2 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
        </div>
      )}
    </div>
  );
}
