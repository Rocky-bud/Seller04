import { useState, useEffect } from 'react';
import { useShop } from '../contexts/ShopContext';
import { fetchDashboardStats } from '../hooks/useApi';
import { formatToman, statusLabels, statusColors } from '../utils/helpers';
import { TrendingUp, Clock, AlertTriangle, ShoppingCart, CheckCircle2, XCircle } from 'lucide-react';

export default function Dashboard() {
  const { shopId } = useShop();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!shopId) return;
    setLoading(true);
    fetchDashboardStats(shopId)
      .then(setStats)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [shopId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-3 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!stats) {
    return <div className="text-center text-slate-500 py-12">خطا در بارگذاری اطلاعات</div>;
  }

  const cards = [
    {
      label: 'کل فروش',
      value: formatToman(stats.totalRevenue),
      icon: TrendingUp,
      color: 'from-emerald-500 to-emerald-600',
      bgLight: 'bg-emerald-50',
      textColor: 'text-emerald-700'
    },
    {
      label: 'سفارشات در انتظار تأیید',
      value: stats.pendingCount,
      icon: Clock,
      color: 'from-primary-500 to-primary-600',
      bgLight: 'bg-primary-50',
      textColor: 'text-primary-700'
    },
    {
      label: 'هشدار موجودی انبار',
      value: stats.lowStockAlerts.length,
      icon: AlertTriangle,
      color: 'from-amber-500 to-amber-600',
      bgLight: 'bg-amber-50',
      textColor: 'text-amber-700'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-800">میز کار</h1>
        <p className="text-sm text-slate-500 mt-1">نمای کلی وضعیت فروشگاه شما</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {cards.map(({ label, value, icon: Icon, color, bgLight, textColor }) => (
          <div
            key={label}
            className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow overflow-hidden"
          >
            <div className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-500">{label}</p>
                  <p className={`text-2xl font-bold mt-2 ${textColor}`}>{value}</p>
                </div>
                <div className={`w-11 h-11 rounded-xl ${bgLight} flex items-center justify-center`}>
                  <Icon className={`w-5 h-5 ${textColor}`} />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">خلاصه سفارشات</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-600">کل سفارشات</span>
              </div>
              <span className="text-sm font-bold text-slate-800">{stats.totalOrders}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-success-50 rounded-xl">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-success-600" />
                <span className="text-sm text-success-600">تأیید شده</span>
              </div>
              <span className="text-sm font-bold text-success-600">{stats.approvedOrders}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-danger-50 rounded-xl">
              <div className="flex items-center gap-2">
                <XCircle className="w-4 h-4 text-danger-600" />
                <span className="text-sm text-danger-600">رد شده</span>
              </div>
              <span className="text-sm font-bold text-danger-600">
                {stats.totalOrders - stats.approvedOrders - stats.pendingCount}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5">
          <h3 className="text-sm font-semibold text-slate-700 mb-4">هشدارهای موجودی</h3>
          {stats.lowStockAlerts.length === 0 ? (
            <div className="text-sm text-slate-400 text-center py-8">موجودی همه محصولات کافی است</div>
          ) : (
            <div className="space-y-2">
              {stats.lowStockAlerts.map(p => (
                <div key={p.id} className="flex items-center justify-between p-3 bg-warning-50 rounded-xl">
                  <span className="text-sm text-slate-700">{p.name}</span>
                  <span className="text-sm font-bold text-warning-600">فقط {p.stock} عدد</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
